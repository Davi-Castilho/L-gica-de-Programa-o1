#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void main(void)
{
int x,y;
float adicao;
printf("\n digite o valor de x: ");
scanf("%d",&x);
printf("\n digite o valor de y: ");
scanf("%d",&y);
adicao=x+y;
printf("\n o resultado de %d + %d=%d",x,y,x+y);
float subtracao;
subtracao=x-y;
printf("\n o resultado de %d - %d=%d",x,y,x-y);
float multiplicacao;
multiplicacao=x*y;
printf("\n o resultado de %d * %d=%d",x,y,x*y);	
}
