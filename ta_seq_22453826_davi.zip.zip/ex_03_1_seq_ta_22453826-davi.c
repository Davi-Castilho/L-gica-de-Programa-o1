#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void main(void)
{
float b,h,area;
printf("\n digite o valor de b: ");
scanf("%f",&b);
printf("\n digite o valor de h: ");
scanf("%f",&h);
area=(b*h)/2;
printf("\n a area do de triangulo de base %.2f e altura %.2f=%.2f",b,h,area);	
}
