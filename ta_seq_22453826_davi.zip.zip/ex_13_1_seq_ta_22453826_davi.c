#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void main(void)
{
int pe=0;
float metros=0.3048;
printf("\n digite o valor de pe: ");
scanf("%d",&pe);
float multiplicacao;
multiplicacao=pe*metros;
printf("\n o resultado de %d * %.4f= %.4fm",pe,metros,pe*metros);
	
}
