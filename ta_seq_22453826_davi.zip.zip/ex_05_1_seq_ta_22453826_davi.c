#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void main(void)
{
float F,C;
printf("\n digite o valor de F: ");
scanf("%f",&F);
C=(F-32)/1.8;
printf("\n o resultao de %.1fF=%.1fC",F,C);	
}

