#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void main(void)
{
int a,b,raiz;
printf("\n forneca o valor de b: ");
scanf("%d",&b);
printf("\n forneca o valor de a: ");
scanf("%d",&a);
raiz= (-b/a);
printf("\n o resultado da raiz  -%d/%d =%d",b,a,raiz);	
}
