#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void main(void)
{
float a,b;
printf("\n digite o valor de a: ");
scanf("%f",&a);
printf("\n digite o valor de b: ");
scanf("%f",&b);
printf("\n os valores de a=%.2f e b=%.2f",a,b);
float soma;
soma=a+b;
printf("\n o resultado de %.2f + %.2f=%.2f",a,b,a+b);
float subtracao;
subtracao=a-b;
printf("\n o resultado de %.2f - %.2f=%.2f",a,b,a-b);	
}

