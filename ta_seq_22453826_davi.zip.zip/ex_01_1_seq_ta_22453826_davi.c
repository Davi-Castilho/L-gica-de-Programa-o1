#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void main(void)
{
float a,b,soma;
printf("\n digite o valor de a: ");
scanf("%f",&a);
printf("\n digite o valor de b: ");
scanf("%f",&b);
soma=a+b;
printf("\n o valor de %.2f + %.2f=%.2f",a,b,soma);	
}
