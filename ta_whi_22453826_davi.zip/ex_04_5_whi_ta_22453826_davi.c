#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int main()
{
int i;
float media,soma,x;
printf("\n informe a quantidade de alunos: ");
scanf("%d",&i);
i=1;
while(i<=50){
printf("\n informe a nota do aluno %d: ",i);
scanf("%f",&x);
soma+=x;
i++;
}
media=soma/50;
printf("\n a media da turma e %.2f",media);
}
