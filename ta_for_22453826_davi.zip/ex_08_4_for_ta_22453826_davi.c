#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int main()
{
int n,i;
double H=0.0;
printf("\n informe o valor de n: ");
scanf("%d",&n);
for (i=1;i<=n;i++){
H +=1.0/i;
}
printf("\n o valor de H e %.2f",H);{
}
}
