#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void main(void)
{ int x;
printf("\n digite o valor de x: ");
scanf("%d",&x);
if(x%2==0)
   {printf(" o valor %d e par",x);}
else
   {printf(" o valor %d e impar",x);}

}


