#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void main(void)
{
int a;
printf("\n digite o valor de a: ");
scanf("%d",&a);
if(a>=100)
    {printf("o valor %d e maior ou igual a cem",a);}
else
	{printf("o valor %d e menor que cem",a);}
	
}
