#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<math.h>
void main(void)
{
int a,b,c,delta,x,y;
printf("\n informe o valor de a,b,c: ");
scanf("%d%d%d",&a,&b,&c);
delta=pow(b,2) - (4*a*c);
if(delta<0)
  {printf("nao possui raizes reais");}
else if(delta>0) {
  x= (-b + sqrt(delta))/2*a;
  y= (-b - sqrt(delta))/2*a;
   printf("possui raizes reais e diferentes sendo elas %d e %d",x,y,delta);
}else if(delta==0) {
 x= (-b + sqrt(delta))/2*a;
 
 y= (-b - sqrt(delta))/2*a;
  printf("ambas as raizes sao iguais %d e %d",x,y,delta);}
}


